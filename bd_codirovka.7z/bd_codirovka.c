//��+����������
#include <stdio.h>

int main(){
    system("chcp 1251 >> null");
    int a;
    char text1[1024] = "decrypted.txt";
    char text2[1024] = "encrypted.txt";
    char filename1[1024] = "";
    char filename2[1024] = "";
    int symbol;
    char xor[] = "mishka";            //����
    int n = sizeof(xor) / sizeof(xor[0]) - 1;
    int index = 0;
    FILE *file;
    FILE *fileX;
    printf("1. �����������\n2. ������������\n");
    scanf("%d", &a);
    switch(a){
        case 1: strcpy (filename1, text1);
                strcpy (filename2, text2);
                file = fopen(filename1, "rb");
                fileX = fopen(filename2, "wb");
                while((symbol = fgetc(file)) != EOF){
                    fprintf(fileX,"%c", symbol^xor[index]);
                    index++;
                    if(index == n) index = 0;
                }
                printf("\n������!");
                break;
        case 2: strcpy (filename1, text2);
                strcpy (filename2, text1);
                file = fopen(filename1, "rb");
                fileX = fopen(filename2, "wb");
                while((symbol = fgetc(file)) != EOF){
                    //printf("%c", symbol^xor[index]);
                    fprintf(fileX,"%c", symbol^xor[index]);
                    index++;
                    if(index == n) index = 0;
                }
                printf("\n������!");
                break;
        default: printf("\n��� ������ �������� ������!");
    }
    fclose(file);
    fclose(fileX);
    return 0;
}
